
from transformers import pipeline

summarizer = pipeline("summarization")

def summarize_text(text):
    result = summarizer(text, max_length=40, min_length=10)
    return result[0]['summary_text']
