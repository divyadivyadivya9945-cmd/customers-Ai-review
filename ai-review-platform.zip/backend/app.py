
from flask import Flask, request, jsonify
from sentiment import analyze_sentiment
from summarizer import summarize_text

app = Flask(__name__)

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    review = data['review']

    sentiment = analyze_sentiment(review)
    summary = summarize_text(review)

    return jsonify({
        "sentiment": sentiment,
        "summary": summary
    })

if __name__ == '__main__':
    app.run(debug=True)
