
async function analyzeReview() {

const review = document.getElementById("review").value;

const response = await fetch("http://127.0.0.1:5000/analyze", {

method: "POST",
headers: { "Content-Type": "application/json" },

body: JSON.stringify({ review })

});

const data = await response.json();

document.getElementById("result").innerHTML =
"Sentiment: " + data.sentiment +
"<br>Summary: " + data.summary;
}
